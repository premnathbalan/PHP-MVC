<?php
App::uses('AppController', 'Controller');
/**
 * MonthYears Controller
 *
 * @property MonthYear $MonthYear
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class MonthYearsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Flash', 'Session');

/**
 * index method
 *
 * @return void
 */
	public function index() {		/* $this->MonthYear->recursive = 0;		$this->set('monthYears', $this->Paginator->paginate()); */		$access_result = $this->checkPathAccess($this->Auth->user('id'));		if (!$access_result) {			$results = $this->MonthYear->find('all', array(					'fields' => array('MonthYear.id','MonthYear.year','MonthYear.month_id','MonthYear.publishing_date'),					'order' => array('MonthYear.id DESC'),					'contain'=>array(							'Month'=>array(									'fields' => array('Month.id','Month.tamil_month_name','Month.month_name',),									'order' => array('Month.id ASC'),
							)
					)
			));			//pr($results);			$this->set('monthYears', $results);		} else {			$this->render('../Users/access_denied');		}	}

	public function findMonthYearsByBatch($id = null) {
		$options = array('conditions' => array('MonthYear.batch_id'=> $id), 'fields' => array('MonthYear.id', 'MonthYear.month_year'/* ,'Batch.batch_to' */));
		$this->set('monthYears', $this->MonthYear->find('list', $options));
		$this->layout=false;
	}
/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {		if (!$this->MonthYear->exists($id)) {			throw new NotFoundException(__('Invalid month year'));		}		$access_result = $this->checkPathAccess($this->Auth->user('id'));		if (!$access_result) {
			$options = array('conditions' => array('MonthYear.' . $this->MonthYear->primaryKey => $id));			$this->set('monthYear', $this->MonthYear->find('first', $options));		} else {			$this->render('../Users/access_denied');		}		$this->layout=false;
	}


/**
 * add method
 *
 * @return void
 */
	public function add() {		$access_result = $this->checkPathAccess($this->Auth->user('id'));		if (!$access_result) {			if ($this->request->is('post')) {				$this->request->data['MonthYear']['created_by'] = $this->Auth->user('id');				$this->request->data['MonthYear']['publishing_date'] = date("Y-m-d", strtotime($this->request->data['MonthYear']['publishing_date']));				$this->MonthYear->create();				if ($this->MonthYear->save($this->request->data)) {					$this->Flash->success(__('The month year has been saved.'));					echo "success";exit;				} else {					//$this->MonthYear->validationErrors = array();					$this->request->data['MonthYear']['publishing_date'] = date("d-m-Y", strtotime($this->request->data['MonthYear']['publishing_date']));					$this->Flash->error(__('The month year could not be saved. Please, try again.'));				}			}			$this->layout=false;			$months = $this->MonthYear->Month->find('list');			$this->set(compact('months'));		}		else {			$this->render('../Users/access_denied');		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {		$access_result = $this->checkPathAccess($this->Auth->user('id'));		if (!$access_result) {
			if (!$this->MonthYear->exists($id)) {	
				throw new NotFoundException(__('Invalid month year'));	
			}	
			$this->request->data['MonthYear']['modified_by'] = $this->Auth->user('id');	
			if ($this->request->is(array('post', 'put'))) {	
				$this->request->data['MonthYear']['publishing_date'] = date("Y-m-d", strtotime($this->request->data['MonthYear']['publishing_date']));				
				if ($this->MonthYear->save($this->request->data)) {	
					$this->Flash->success(__('The month year has been saved.'));	
					echo "success";exit;	
				} else {					$errors ="";					if(isset($this->MonthYear->validationErrors['year'][0])){						$errors .= $this->MonthYear->validationErrors['year'][0].". ";					}					if(isset($this->MonthYear->validationErrors['publishing_date'][0])){						$errors .= $this->MonthYear->validationErrors['publishing_date'][0].". ";					}
					$this->request->data['MonthYear']['publishing_date'] = date("d-m-Y", strtotime($this->request->data['MonthYear']['publishing_date']));	
					$this->Flash->error(__($errors.'The Month Year Could not be Saved.'));				}	
			} else {	
				$options = array('conditions' => array('MonthYear.' . $this->MonthYear->primaryKey => $id));	
				$this->request->data = $this->MonthYear->find('first', $options);	
			}			$this->request->data['MonthYear']['publishing_date'] = date("d-M-Y", strtotime($this->request->data['MonthYear']['publishing_date']));		}		else {			$this->layout=false;			$this->render('../Users/access_denied');		}		$months = $this->MonthYear->Month->find('list');				$this->set(compact('months'));				$this->layout=false;				
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {		$access_result = $this->checkPathAccess($this->Auth->user('id'));		if (!$access_result) {			$this->MonthYear->id = $id;			if (!$this->MonthYear->exists()) {				throw new NotFoundException(__('Invalid month year'));			}			$this->request->allowMethod('post', 'delete');			if ($this->MonthYear->delete()) {				$this->Flash->success(__('The month year has been deleted.'));			} else {				$this->Flash->error(__('The month year could not be deleted. Please, try again.'));			}			return $this->redirect(array('action' => 'index'));		}		else {			$this->render('../Users/access_denied');		}	}
}
