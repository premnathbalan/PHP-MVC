<?php
App::uses('AppModel', 'Model');
/**
 * Country Model
 *
 * @property Zone $Zone
 */
class ModifiedUser extends User {
		public $useTable = 'users';
}