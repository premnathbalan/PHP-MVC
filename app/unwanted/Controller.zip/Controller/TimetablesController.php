<?php
App::uses('AppController', 'Controller');
App::import('controller', 'ContinuousAssessmentExams');
/**
 * Timetables Controller
 *
 * @property Timetable $Timetable
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class TimetablesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Flash', 'Session');
	public $uses = array("Timetable","CourseMapping", "Batch", "Program", "MonthYear","Academic","ExamAttendance","StudentMark",
			"Student"
	);
	public $lastDateAssigned=array();
/**
 * index method
 *
 * @return void
 */
				
	public function index() {
		$access_result = $this->checkPathAccess($this->Auth->user('id'));
		if (!$access_result) {
			$academics = $this->Program->Academic->find('list',array('order' => array('Academic.academic_name ASC')));
			$programs = $this->Program->find('list',array('order' => array('Program.program_name ASC')));
			$batches = $this->Batch->find('list', array('fields' => array('Batch.batch_period'),'order' => array('Batch.batch_to DESC')));
			$monthyears = $this->MonthYear->getAllMonthYears();
			$this->set(compact('academics','programs','batches','monthyears'));
		}
		else {
			$this->render('../Users/access_denied');
		}
	}
	
	public function searchIndex($examMonth = null,$batchId = null,$Academic = null,$programId = null,$exam_type = null) {	
		
		$conditions=array();$batchCond=array();$progCond = array();
		$conditions['Timetable.indicator'] = 0;
		if($examMonth !='-'){			
			$conditions['Timetable.month_year_id'] = $examMonth;
		}
		if($batchId !='-'){
			$batchCond['Batch.id'] = $batchId;			
		}
		if($programId !='-'){
			$progCond['Program.id'] = $programId;
		}
		if($exam_type !='-'){
			$conditions['Timetable.exam_type'] = $exam_type;
		}		
		$result = array(
			'conditions' => $conditions,				
			'fields' =>array('Timetable.id','Timetable.exam_date','Timetable.exam_session','Timetable.exam_type','Timetable.month_year_id'),
			'contain'=>array(
				'MonthYear'=>array('fields' =>array('MonthYear.year'),
					'Month'=>array('fields' =>array('Month.month_name'))
				),
				'CourseMapping'=>array('fields'=>array('CourseMapping.id',  'CourseMapping.program_id', 'CourseMapping.course_number', 'CourseMapping.course_mode_id','CourseMapping.semester_id', 'CourseMapping.month_year_id'),
					'MonthYear'=>array('fields' =>array('MonthYear.year'),
						'Month'=>array('fields' =>array('Month.month_name'))
					),
					'Program'=>array('fields' =>array('Program.program_name'),
						'Academic'=>array('fields' =>array('Academic.academic_name')),'conditions' => $progCond
					),
					'Course'=>array('fields' =>array('Course.course_code','Course.course_name')),
					'Batch'=>array('fields' =>array('Batch.batch_from','Batch.batch_to','Batch.academic'),'conditions' => $batchCond),
				),
				'ExamAttendance'=>array('fields' =>array('ExamAttendance.id')),
			),			
			'recursive' => 1
		);
		$results = $this->Timetable->find("all", $result);
		$this->set('timetables', $results);
		$this->set('batchId', $batchId);
		$this->set('programId', $programId);
		$this->set('Academic', $Academic);
		$this->set('exam_type', $exam_type);		
		$this->layout=false;
	}
/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Timetable->exists($id)) {
			throw new NotFoundException(__('Invalid timetable'));
		}
		$options = array('conditions' => array('Timetable.' . $this->Timetable->primaryKey => $id));
		$this->set('timetable', $this->Timetable->find('first', $options));
		//$this->layout=false;
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		$academics = $this->Program->Academic->find('list',array('order' => array('Academic.academic_name ASC')));
		$programs = $this->Program->find('list',array('order' => array('Program.program_name ASC')));
		$batches = $this->Batch->find('list', array('fields' => array('Batch.batch_period'),'order' => array('Batch.batch_to DESC')));
		$monthYears = $this->MonthYear->find('all', array(
				'fields' => array('MonthYear.id','MonthYear.year','MonthYear.month_id','Month.month_name'),
				'order' => array('MonthYear.id DESC'),
				'recursive'=>0
		));
		$monthyears=array();
		
		foreach ($monthYears as $key => $value) {
			$monthyears[$value['MonthYear']['id']]=$value['Month']['month_name']."-".$value['MonthYear']['year'];
		}
		$this->set(compact('academics','programs','batches','monthyears'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Timetable->exists($id)) {
			throw new NotFoundException(__('Invalid timetable'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Timetable->save($this->request->data)) {
				$this->Flash->success(__('The timetable has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The timetable could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Timetable.' . $this->Timetable->primaryKey => $id));
			$this->request->data = $this->Timetable->find('first', $options);
		}
		//$this->layout=false;
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Timetable->id = $id;
		if (!$this->Timetable->exists()) {
			throw new NotFoundException(__('Invalid timetable'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Timetable->delete()) {
			$this->Flash->success(__('The timetable has been deleted.'));
		} else {
			$this->Flash->error(__('The timetable could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
	
	public function search($examMonth = null, $batchId = null, $academic_id = null, $programId = null, $semesterId = null,$exam_type = null) {		
		$examMYId =  array();$batchCond=array();$progCond = array();$ttEMId = array();
		$stuMId = array();
		if($examMonth !='-'){			
			$examMYId['CourseMapping.month_year_id !='] = $examMonth;
			$ttEMId['Timetable.month_year_id'] = $examMonth;
			/*$stuMId['StudentMark.month_year_id'] = $examMonth;*/
		}
		if($batchId !='-'){
			$batchCond['CourseMapping.batch_id'] = $batchId;
		}
		if($programId !='-'){
			$progCond['CourseMapping.program_id'] = $programId;
		}
		
		if($this->request->is('post')) {
			if(isset($this->request->data['Confirm'])){
				for($i=1; $i<=$this->request->data['maxRow'];$i++) {
					if(isset($this->request->data['Timetable']['exam_date'.$i])){
						$data = array();
						$data['Timetable']['month_year_id']		= $this->request->data['month_year_id'];
						$data['Timetable']['course_mapping_id'] = $this->request->data['Timetable']['CM'.$i];
						$data['Timetable']['exam_date'] 		= date("Y-m-d", strtotime($this->request->data['Timetable']['exam_date'.$i]));
						$data['Timetable']['exam_session'] 		= $this->request->data['Timetable']['exam_session'.$i];
						$data['Timetable']['exam_type'] 		= $this->request->data['exam_type'];
		
						$chk =$this->Timetable->find('first',
								array('conditions' => array(
										'Timetable.month_year_id' => $data['Timetable']['month_year_id'],
										'Timetable.course_mapping_id' => $data['Timetable']['course_mapping_id']
									),'recursive'=>1));
					
						if($chk){
							$data['Timetable']['modified_by'] 		= $this->Auth->user('id');
							$data['Timetable']['id'] 				= $chk['Timetable']['id'];
							$this->Flash->success(__('The Time Table has been updated.'));
						}else{
							$data['Timetable']['created_by'] 		= $this->Auth->user('id');
							$this->Timetable->create();
							$this->Flash->success(__('The Time Table has been saved.'));
						}
						$this->Timetable->save($data);
					}
				}
				return $this->redirect(array('action' => 'index'));			
			}
		}
	if($exam_type == 'A'){ 
		$searchResult = array();
		//Get Other Data(Arrear, Late join...) Start  
	 $qryResult =  $this->CourseMapping->find('all',  array(
      'conditions' => array('CourseMapping.indicator' => 0, $examMYId,$batchCond, $progCond,'Course.course_type_id ' =>  array(1, 3)),
      'fields' => array('CourseMapping.id', 'CourseMapping.batch_id', 'CourseMapping.program_id',
          'CourseMapping.month_year_id', 'CourseMapping.semester_id'),				
	      'contain' => array(
	      		'CourseStudentMapping' =>array('fields' =>array('CourseStudentMapping.new_semester_id','CourseStudentMapping.student_id'),
	      				'conditions'=>array('CourseStudentMapping.new_semester_id' => $semesterId),
	      			'CourseMapping' => array('fields' =>array('CourseMapping.id'),
	      				'Course' => array(
      						'fields' => array('Course.course_code', 'Course.course_name'),      						
      					),
      					'Timetable' =>array('fields' =>array('Timetable.exam_date','Timetable.exam_session','Timetable.exam_type'),
      							'ExamAttendance'=>array('fields' =>array('ExamAttendance.id')),
      							'conditions'=>$ttEMId,
      					),
					),
	      		),
	      		'Course' => array(
	      				'fields' => array('Course.course_code', 'Course.course_name'),
	      				'CourseType' => array(
	      						'fields' => array('CourseType.course_type')
	      				)
	      		),
	      		'Timetable' =>array('fields' =>array('Timetable.exam_date','Timetable.exam_session','Timetable.exam_type'),
	      				'ExamAttendance'=>array('fields' =>array('ExamAttendance.id')),
	      				'conditions'=>$ttEMId,
	      		),	      		
	      		'StudentMark'=>array(
      				'conditions' => array(
      						'OR' => array(
      								array('StudentMark.revaluation_status' => "0", 'StudentMark.status' => 'Fail'),
      								array('StudentMark.revaluation_status' => "1", 'StudentMark.final_status'=>'Fail'),
      						),
      						'StudentMark.indicator' => 0
      				),
      				'fields'=>array(
      						'StudentMark.id', 'StudentMark.student_id'
      				)
	      		)
	      	),'group'=>array('CourseMapping.id')
		)); 
	 
	 foreach($qryResult as $key=>$result){
	 	$csm = $result['CourseStudentMapping'];
	 	$sm = $result['StudentMark'];
	 	if (count($csm)>0 || count($sm)>0) {
		 	if(isset($result['Timetable'][0]['exam_session'])){
		 		$searchResult[$result['CourseMapping']['id']]['exam_session'] = $result['Timetable'][0]['exam_session'];
		 	}
		 	if(isset($result['Timetable'][0]['exam_date'])){
		 		$searchResult[$result['CourseMapping']['id']]['exam_date'] = $result['Timetable'][0]['exam_date'];
		 	}
		 	if(isset($result['Timetable'][0]['ExamAttendance']) && count($result['Timetable'][0]['ExamAttendance'])>0) {
		 		$searchResult[$result['CourseMapping']['id']]['attendance'] = "Y";
		 	} else {
		 		$searchResult[$result['CourseMapping']['id']]['attendance'] = "N";
		 	}
		 	$searchResult[$result['CourseMapping']['id']]['course_code'] = $result['Course']['course_code'];
		 	$searchResult[$result['CourseMapping']['id']]['course_name'] = $result['Course']['course_name'];
	 	}
	 }
	 
		//Get Other data(Arrear, Late join...) end
	}else{	
		$result = array(
			'conditions' => array(
				array('CourseMapping.batch_id' => $batchId,
					'CourseMapping.program_id' => $programId,
					'CourseMapping.indicator' => 0,
					'CourseMapping.semester_id' => $semesterId,
					'Course.course_type_id' =>  array(1, 3)
				)
			),
			'fields' =>array('CourseMapping.id',  'CourseMapping.program_id', 'CourseMapping.course_number', 'CourseMapping.course_mode_id','CourseMapping.semester_id', 'CourseMapping.month_year_id'),
				
			'contain'=>array(			
				'Timetable' =>array('fields' =>array('Timetable.exam_date','Timetable.exam_session','Timetable.exam_type'),
					'ExamAttendance'=>array('fields' =>array('ExamAttendance.id')),
				),
				'Course'=>array('fields' =>array('Course.course_code','Course.course_name')),
				'Program'=>array('fields' =>array('Program.program_name'),							
					'Academic'=>array('fields' =>array('Academic.academic_name')),							
				),	
			),							
	
			'recursive' => 2
		);
		$searchResult = $this->Timetable->CourseMapping->find("all", $result);
	} 
		$this->set('results', $searchResult);//pr( $searchResult);
		
		$this->set('examMonth', $examMonth);
		$this->set('batchId', $batchId);
		$this->set('academic_id', $academic_id);
		$this->set('programId', $programId);
		$this->set('semesterId', $semesterId);
		$this->set('exam_type', $exam_type);
		
		$this->layout=false;
	}
	
	public function listCourses($batchId = null, $academic_id = null, $programId = null, $month_year_id = null) {
		
		$result = array(
				'conditions' => array(
						array('CourseMapping.batch_id' => $batchId,
								'CourseMapping.program_id' => $programId,
								'CourseMapping.indicator' => 0,
								'CourseMapping.month_year_id' => $month_year_id
						)
				),
				'fields' =>array('Timetable.id','Timetable.exam_date','Timetable.exam_session','Timetable.exam_type'),
				'contain'=>array(
						'CourseMapping'=>array(
								'fields' =>array('CourseMapping.id',  'CourseMapping.program_id', 'CourseMapping.course_number', 'CourseMapping.course_mode_id','CourseMapping.semester_id', 'CourseMapping.month_year_id'),
								'Course'=>array('fields' =>array('Course.course_code','Course.course_name')),
								'Program'=>array('fields' =>array('Program.program_name'),
										'Academic'=>array('fields' =>array('Academic.academic_name')),
								),
						),
				),
					
				'recursive' => 2
		);
		
		$listCourses = array();
		$searchResult = $this->Timetable->find("all", $result);
		foreach ($searchResult as $searchResults) {
			$listCourses[$searchResults['Timetable']['id']] = $searchResults['CourseMapping']['Course']['course_code']." - ".$searchResults['CourseMapping']['Course']['course_name'];
		}
		$this->set('listCourses', $listCourses);
		$this->layout=false;
	}
	
	public function timetableReport() {
		$monthyears = $this->MonthYear->getAllMonthYears();
		$this->set(compact('monthyears'));
	}
	
	public function timetableReportSearch($examMonth, $exam_type, $opt) {
		$conditions=array();
		$conditions['Timetable.indicator'] = 0;
		if($examMonth !='-'){
			$conditions['Timetable.month_year_id'] = $examMonth;
			//$conditions['Timetable.id'] = 220;
		}
		if($exam_type !='-'){
			if ($exam_type == 'B') $conditions['Timetable.exam_type'] = array('R', 'A');
			else $conditions['Timetable.exam_type'] = $exam_type;
		}
		$result = array(
				'conditions' => $conditions,
				'fields' =>array('Timetable.id','Timetable.exam_date','Timetable.exam_session','Timetable.exam_type',
									'Timetable.month_year_id'
				),
				'contain'=>array(
						'CourseMapping'=>array(
								'fields'=>array('CourseMapping.id',  'CourseMapping.program_id', 'CourseMapping.batch_id', 
										'CourseMapping.course_number',  'CourseMapping.semester_id', 'CourseMapping.month_year_id'
								),
						),
						'ExamAttendance'=>array('fields' =>array('ExamAttendance.id', 'ExamAttendance.attendance_status')),
				),
				'order'=>array('Timetable.id'),
				'recursive' => 1
		);
		$results = $this->Timetable->find("all", $result);
		//pr($results);
		$final_array = $this->processTimetableReport($results);
		//pr($final_array);
		$timetable_month_year = $this->getMonthYearName($examMonth);
		if ($opt == 'search') {
			$this->set(compact('final_array', 'examMonth', 'timetable_month_year', 'exam_type'));
		}
		else if ($opt=='excel') {
			$results = $this->array_MultiOrderBy($final_array,'exam_date', SORT_ASC,'exam_session', SORT_DESC, 'course_code', SORT_ASC);
			//echo count($results);
			//pr($results); 
			$this->timetableReportExcel($results, $examMonth, $exam_type);
			$this->autoRender=false;
		}
		$this->layout=false;
	}
	
	public function processTimetableReport($results) {
		$final_array=array();
		
		foreach ($results as $key => $value) { 
			$exam_attendance = $value['ExamAttendance'];
			$total=0;
			$present=0;
			$absent=0;
			$exam_date='';
			$total = count($exam_attendance);
			
			//$exam_date = date( "d-M-Y", strtotime($value['Timetable']['exam_date'])); 
			
			$final_array[$key]['timetable_id'] = $value['Timetable']['id'];
			$final_array[$key]['exam_date'] = $value['Timetable']['exam_date'];
			$final_array[$key]['exam_session'] = $value['Timetable']['exam_session'];
			
			if ($value['Timetable']['exam_type'] == 'R') $exam_type = "Regular";
			if ($value['Timetable']['exam_type'] == 'A') $exam_type = "Arrear";
			
			$final_array[$key]['exam_type'] = $exam_type;
			
			$final_array[$key]['timetable_month_year_id'] = $value['Timetable']['month_year_id'];
			$final_array[$key]['course_mapping_id'] = $value['CourseMapping']['id'];
			$final_array[$key]['batch_id'] = $value['CourseMapping']['batch_id'];
			$final_array[$key]['program_id'] = $value['CourseMapping']['program_id'];
			$final_array[$key]['month_year_id'] = $value['CourseMapping']['month_year_id'];
			
			$txt_month_year = $this->getMonthYearName($value['CourseMapping']['month_year_id']);
			//pr($txt_month_year);
			$final_array[$key]['txt_month_year'] = $txt_month_year;
			$basic_details = $this->getCourseNameCrseCodeCmnCodeFromCMId($value['CourseMapping']['id']);
			
			$b_academic = $basic_details[0]['Batch']['academic'];
			if ($b_academic == "JUN") $b_academic='[A]'; 
			$batch = $basic_details[0]['Batch']['batch_from']." - ".$basic_details[0]['Batch']['batch_to']." ".$b_academic;
			
			$academic = $basic_details[0]['Program']['Academic']['short_code'];
			$program = $basic_details[0]['Program']['short_code'];
			$course_code = $basic_details[0]['Course']['course_code'];
			$common_code = $basic_details[0]['Course']['common_code'];
			$course_name = $basic_details[0]['Course']['course_name'];
			
			//pr($basic_details);
			foreach ($exam_attendance as $k => $attValue) {
				if ($attValue['attendance_status']==0) $absent++;
				else if ($attValue['attendance_status']==1) $present++;
			}
			
			$final_array[$key]['batch'] = $batch;
			$final_array[$key]['academic'] = $academic;
			$final_array[$key]['program'] = $program;
			$final_array[$key]['course_code'] = $course_code;
			$final_array[$key]['common_code'] = $common_code;
			$final_array[$key]['course_name'] = $course_name;
			$final_array[$key]['total_strength'] = $total;
			$final_array[$key]['present'] = $present;
			$final_array[$key]['absent'] = $absent;
			
		}
		return $final_array;
	}
	
	private function getDateForSpecificDayBetweenDates($startDate, $endDate, $weekdayNumber) {
		$startDate = strtotime($startDate);
		$endDate = strtotime($endDate);
	
		$dateArr = array();
	
		do
		{
			if(date("w", $startDate) != $weekdayNumber)
			{
				$startDate += (24 * 3600); // add 1 day
			}
		} while(date("w", $startDate) != $weekdayNumber);
	
	
		while($startDate <= $endDate)
		{
			$dateArr[] = date('Y-m-d', $startDate);
			$startDate += (7 * 24 * 3600); // add 7 days
		}
	
		return($dateArr);
	}
	
	public function timetable() {
		$monthYears = $this->MonthYear->find('all', array('fields' => array('MonthYear.id','MonthYear.year','MonthYear.month_id','Month.month_name')));
		$monthyears=array();
		foreach ($monthYears as $key => $value) {
			$monthyears[$value['MonthYear']['id']]=$value['Month']['month_name']."-".$value['MonthYear']['year'];
		}
		krsort($monthyears);
		$this->set(compact('monthyears'));
		
	}
	
	public function test ($exam_month_year_id) {
		$array = array();
	
		//Step 1: GET UP-TO-DATE ARREAR DATA FROM STUDENTMARK TABLE
		$arrear_results = $this->getArrearDataBasedOnCourseType($exam_month_year_id, Configure::read('CourseType.theory'));
		//RE-ARRANGE THE RESULTSET BASED ON COURSE_MAPPING_ID. THIS IS NOT NECESSARY
		//$cm_id_course_code_array = $this->retriveCmIdCourseCodeFromArrearResults($results);
		/*RE-ARRANGE THE RESULTSET BASED ON COURSE_CODE. USEFUL AS TIMETABLE IS GENERATED BASED ON COMMON COURSE CODE */
		$arrear_course_code_array = $this->retriveCourseCodeCmIdFromArrearResults($arrear_results);
		//pr($arrear_course_code_array);
		$array['StudentMark'] = $arrear_course_code_array;
		//$array['cm_id']['StudentMark'] = $cm_id_course_code_array;
	
		//Step 2: GET ARREAR DATA FROM COURSE_STUDENT_MAPPING TABLE
		$non_arrear_results = $this->getNonArrearDataBasedOnCourseType($exam_month_year_id, Configure::read('CourseType.theory'));
		//RE-ARRANGE THE RESULTSET BASED ON COURSE_MAPPING_ID. THIS IS NOT NECESSARY
		//$cm_id_non_arrear_course_code_array = $this->retriveCmIdCourseCodeFromNonArrearResults($non_arrear_results);
		/*RE-ARRANGE THE RESULTSET BASED ON COURSE_CODE. USEFUL AS TIMETABLE IS GENERATED BASED ON COMMON COURSE CODE */
		$non_arrear_course_code_array = $this->retriveCourseCodeCmIdFromNonArrearResults($non_arrear_results);
		//pr($non_arrear_course_code_array);
		$array['CourseStudentMapping'] = $non_arrear_course_code_array;
		//$array['cm_id']['CourseStudentMapping'] = $cm_id_non_arrear_course_code_array;
	
		//Step 3: GET REGULAR DATA FROM COURSE_MAPPING TABLE
		$regular_results = $this->getRegularDataBasedOnCourseType($exam_month_year_id, Configure::read('CourseType.theory'));
		//pr($regular_results);
		//RE-ARRANGE THE RESULTSET BASED ON COURSE_MAPPING_ID. THIS IS NOT NECESSARY
		//$cm_id_regular_course_code_array = $this->retriveCmIdCourseCodeFromRegularResults($regular_results);
		$regular_course_code_array = $this->retriveCourseCodeCmIdFromRegularResults($regular_results);
		//pr($regular_course_code_array);
		$array['CourseMapping'] = $regular_course_code_array;
		//$array['cm_id']['CourseMapping'] = $cm_id_regular_course_code_array;
	
		$details = array();
	
		//pr($array);
		/* echo "<table border='1'>";
			echo "<tr>";
			echo "<td>Model</td><td>Course_code</td><td>cm_id</td><td>Batch_id</td><td>Program_id</td><td>Course_id</td><td>MonthYearId</td>";
			echo "</tr>"; */
		foreach ($array as $model => $arr) {
			$course_code_details = $arr['course_code_details'];
			foreach ($course_code_details as $course_code => $tmpval) { //pr($tmpval);
				foreach ($tmpval as $cm_id => $value) {
					/* echo "<tr>";
						echo "<td>".$model."</td><td>".$course_code."</td><td>".$cm_id."</td><td>".$value['batch_id']."</td>
						<td>".$value['program_id']."</td><td>".$value['course_id']."</td><td>".$value['month_year_id']."</td>";
						echo "</tr>"; */
					if ($value['month_year_id'] == $exam_month_year_id) $type="R"; else $type="A";
					/* if ($value['month_year_id'] == $exam_month_year_id) {
					 $details['Regular'][$value['batch_duration']][$value['program_id']][$value['course_id']] = $cm_id.",".$value['semester_id'];
						} else {
						$details['Arrear'][$value['batch_duration']][$value['program_id']][$value['course_id']] = $cm_id.",".$value['semester_id'];
						} */
					//$details[$value['batch_duration']][$value['program_id']][$value['course_id']] = $cm_id.",".$value['semester_id'].",".$type;
					//working code
					$details[$value['batch_duration']][$value['course_id']][$cm_id] = $value['semester_id'].",".$type.",".$value['program_id'].",".$value['batch_id'];
				}
			}
		}
		pr($details);
	}
	
	public function ttGeneration ($exam_month_year_id, $startDate, $endDate, $isSundayHoliday, $daysDiff, $exceptionalDates) {
		$array = array();
	
		//Step 1: GET UP-TO-DATE ARREAR DATA FROM STUDENTMARK TABLE
		$arrear_results = $this->getArrearDataBasedOnCourseType($exam_month_year_id, Configure::read('CourseType.theory'));
		//RE-ARRANGE THE RESULTSET BASED ON COURSE_MAPPING_ID. THIS IS NOT NECESSARY
		//$cm_id_course_code_array = $this->retriveCmIdCourseCodeFromArrearResults($results);
		/*RE-ARRANGE THE RESULTSET BASED ON COURSE_CODE. USEFUL AS TIMETABLE IS GENERATED BASED ON COMMON COURSE CODE */
		$arrear_course_code_array = $this->retriveCourseCodeCmIdFromArrearResults($arrear_results);
		//pr($arrear_course_code_array);
		$array['StudentMark'] = $arrear_course_code_array;
		//$array['cm_id']['StudentMark'] = $cm_id_course_code_array;
	
		//Step 2: GET ARREAR DATA FROM COURSE_STUDENT_MAPPING TABLE
		$non_arrear_results = $this->getNonArrearDataBasedOnCourseType($exam_month_year_id, Configure::read('CourseType.theory'));
		//RE-ARRANGE THE RESULTSET BASED ON COURSE_MAPPING_ID. THIS IS NOT NECESSARY
		//$cm_id_non_arrear_course_code_array = $this->retriveCmIdCourseCodeFromNonArrearResults($non_arrear_results);
		/*RE-ARRANGE THE RESULTSET BASED ON COURSE_CODE. USEFUL AS TIMETABLE IS GENERATED BASED ON COMMON COURSE CODE */
		$non_arrear_course_code_array = $this->retriveCourseCodeCmIdFromNonArrearResults($non_arrear_results);
		//pr($non_arrear_course_code_array);
		$array['CourseStudentMapping'] = $non_arrear_course_code_array;
		//$array['cm_id']['CourseStudentMapping'] = $cm_id_non_arrear_course_code_array;
	
		//Step 3: GET REGULAR DATA FROM COURSE_MAPPING TABLE
		$regular_results = $this->getRegularDataBasedOnCourseType($exam_month_year_id, Configure::read('CourseType.theory'));
		//pr($regular_results);
		//RE-ARRANGE THE RESULTSET BASED ON COURSE_MAPPING_ID. THIS IS NOT NECESSARY
		//$cm_id_regular_course_code_array = $this->retriveCmIdCourseCodeFromRegularResults($regular_results);
		$regular_course_code_array = $this->retriveCourseCodeCmIdFromRegularResults($regular_results);
		//pr($regular_course_code_array);
		$array['CourseMapping'] = $regular_course_code_array;
		//$array['cm_id']['CourseMapping'] = $cm_id_regular_course_code_array;
	
		$details = array();
		
		//pr($array);
		/* echo "<table border='1'>";
		echo "<tr>";
		echo "<td>Model</td><td>Course_code</td><td>cm_id</td><td>Batch_id</td><td>Program_id</td><td>Course_id</td><td>MonthYearId</td>";
		echo "</tr>"; */
		foreach ($array as $model => $arr) {
			$course_code_details = $arr['course_code_details'];
			foreach ($course_code_details as $course_code => $tmpval) { //pr($tmpval);
				foreach ($tmpval as $cm_id => $value) {
					/* echo "<tr>";
					echo "<td>".$model."</td><td>".$course_code."</td><td>".$cm_id."</td><td>".$value['batch_id']."</td>
              <td>".$value['program_id']."</td><td>".$value['course_id']."</td><td>".$value['month_year_id']."</td>";
					echo "</tr>"; */
					if ($value['month_year_id'] == $exam_month_year_id) $type="R"; else $type="A";
					/* if ($value['month_year_id'] == $exam_month_year_id) {
						$details['Regular'][$value['batch_duration']][$value['program_id']][$value['course_id']] = $cm_id.",".$value['semester_id'];
					} else {
						$details['Arrear'][$value['batch_duration']][$value['program_id']][$value['course_id']] = $cm_id.",".$value['semester_id'];
					} */
					//$details[$value['batch_duration']][$value['program_id']][$value['course_id']] = $cm_id.",".$value['semester_id'].",".$type;
					//working code
					//$details[$value['batch_duration']][$value['course_id']][$cm_id] = $value['semester_id'].",".$type.",".$value['program_id'].",".$value['batch_id'];
					$details[$value['batch_duration']][$value['course_id']][$cm_id] = array(
							/* 'semester_id'=>$value['semester_id'], */
							'type' => $type, 
							'program_id' => $value['program_id'],
							'batch_id' => $value['batch_id']
					);
				}
			}
		}
		
		//pr($details);
		
		//echo "</table>";
		$tmpDates = explode(",", $exceptionalDates);
		//pr($tmpDates);
		
		$newExceptionaldates = array();
		foreach ($tmpDates as $tmpDate) {
			if(isset($tmpDate)) {
				$tdate = date('Y-m-d', strtotime(trim($tmpDate)));
				$newExceptionaldates[]=$tdate;
			}
		}
		//pr($newExceptionaldates);
		$startDate = date("Y-m-d", strtotime($startDate));
	//	echo $startDate;
		$endDate = date("Y-m-d", strtotime($endDate));
	//	echo $endDate;
		
//pr($details);

	//echo count($details['Arrear'])." ".count($details['Regular']);	
//echo count($details);
		//$all_course_code = array_merge($course_code_array,$non_arrear_course_code_array, $regular_course_code_array);
		//pr($all_course_code);
		//echo count($all_course_code);
	$dateArr = $this->getDateForSpecificDayBetweenDates($startDate, $endDate, 0);
	//pr($dateArr);
	
	$exclude = array_merge($dateArr, array_diff($newExceptionaldates, array_intersect($dateArr, $newExceptionaldates)));
	//pr($exclude);

	$allTimetableDates = $this->dateRange($startDate, $endDate);
	
	$timetableDates = array();
	$timetableDatesAssigned = array();
	
	$timetableDates = array_values(array_diff($allTimetableDates, $exclude));
	
	$i=1;
	foreach ($timetableDates as $tkey => $tvalue) {
		$timetableDates[$i]=$tvalue;
		$i++;
	}
	unset($timetableDates[0]);
	//pr($timetableDates);
	
	foreach ($timetableDates as $tkey => $tvalue) {
		$timetableDatesAssigned[$tvalue]=0;
	}
	//pr($timetableDatesAssigned);
	
	echo "total days : ".count($timetableDates);
	echo "**".count($details[1])."**".count($details[2])."**".count($details[3])."**".count($details[4])."**".count($details[5]);
	
	//Timetable logic starts here
	$batchArray = array();
	//$programArray = array("1"=>"2017-02-01");
	$programArray = array();
	$cmIdArray = array();
	$courseIdArray = array();
	$programExamDateArray = array();
	$pgmToCheck = array();
	
	$lastDate = array();
	
	/* echo $ttLastDate; 
	if (empty($ttLastDate)) echo "if";
	else echo "else";
	echo date('Y-m-d', strtotime($ttLastDate .' +1 day')); */
	
	//$newArray = array();
	$batches = array();
	//$testArray = array();
	
	foreach ($details as $batch_duration => $batchDetails) {
		//pr($timetableDates);
		//pr($timetableDatesAssigned);
		$tmpTimetableDates = $timetableDates;
		$tmpTimetableDatesAssigned = $timetableDatesAssigned;
		
		if ($batch_duration == 1) {
			//pr($details[4]);
			$batches[$batch_duration] = $batch_duration;
			$tmpArray = array();
	
			$tmpArray = $batchDetails;
			//pr($tmpArray);
			echo "Batch duration : ".$batch_duration;
			$varBool = 0; $groupedArray = array();
			
			foreach ($tmpArray as $courseId => $cmDetails) {
				$varBool = 0;
				$pgmToCheck = $this->loopProgramId($cmDetails);
				//pr($pgmToCheck);
				if (empty($groupedArray)) {
					$groupedArray[0][$courseId] = $cmDetails;
					unset($tmpArray[$courseId]);
				}
				else {
					$cnt = count($groupedArray);
					for ($j=0; $j<count($groupedArray); $j++) {
						$pgmInArray[$j] = array();
						$value = $groupedArray[$j];
						foreach ($value as $c_id => $innerValue) {
							foreach ($innerValue as $cm_id => $array) {
								$pgmInArray[$j][$array['program_id']]=$array['program_id'];
							}
						}
					}
					//pr($pgmInArray);
					$notFound = array();
					for ($j=0; $j<count($groupedArray); $j++) {
						if (isset($pgmInArray[$j]) && !array_intersect_key($pgmToCheck, $pgmInArray[$j])) {
							$groupedArray[$j][$courseId] = $cmDetails;
							$notFound[$j] = 1;
							$varBool = 0; 
							unset($tmpArray[$courseId]);
							break;
						} else {
							$notFound[$j] = 0;
							$varBool = 1;
						}
					}
					if ($varBool==1 && !in_array("1", $notFound)) {
						$groupedArray[$cnt][$courseId] = $cmDetails;
						unset($tmpArray[$courseId]);
					}
				}
				
			}
			$cnt = 0;
			foreach ($groupedArray as $key => $value) {
				$cnt+=count($value);
			}
			echo "</br>Count : ".$cnt;
			echo "No. of days : ".count($groupedArray);
			$this->storeTimetableDates($groupedArray, $tmpTimetableDates, $tmpTimetableDatesAssigned, $daysDiff, $batch_duration, $exam_month_year_id);
			}
		}
	//Timetable logic ends here
	$this->layout = false;
	$this->autoRender = false;
	}
	
	public function storeTimetableDates($groupedArray, $timetableDates, $timetableDatesAssigned, $daysDiff, $batch_duration, $exam_month_year_id) {
		//pr($timetableDates);
		//pr($groupedArray);
		$daysDiff = $daysDiff + 1;
		$lastDateAssigned = array();
		foreach ($groupedArray as $k => $crseIdArray) {
			
			if (empty($lastDateAssigned)) {
				if ($batch_duration % 2 == 0) $examDate = $timetableDates[1];
				else $examDate = $timetableDates[2];
				$timetableDatesAssigned[$examDate]=1;
			}
			else {
				//pr($lastDateAssigned);
				$prvDate = $lastDateAssigned[count($lastDateAssigned)-1];
//				echo "Previous date : ".$prvDate;
				$aKey = array_keys($timetableDates, $prvDate);
				$nextKey = $aKey[0] + $daysDiff;
//				echo "Next key : ".$nextKey;
				$examDate = $timetableDates[$nextKey];
				if (isset($timetableDatesAssigned[$examDate])) {
					$timetableDatesAssigned[$examDate]=1;
				} else {
					//echo "date unavailable";
					foreach ($timetableDatesAssigned as $eDate => $boolValue) {
						if ($boolValue == 0) {
							$timetableDatesAssigned[$eDate]=1;
							$examDate = $eDate;
							break;
						}
					}
				}
			}
			$lastDateAssigned[]=$examDate;
			//$examDate = $this->examDateSelection($timetableDates, $timetableDatesAssigned, $daysDiff, $batch_duration);
			echo "</br>".$examDate;
			foreach ($crseIdArray as $courseId => $cmArray) {
				foreach ($cmArray as $cm_id => $cmValue) {
					$data = array();
					$data['Timetable']['month_year_id'] = $exam_month_year_id;
					$data['Timetable']['course_mapping_id'] = $cm_id;
					$data['Timetable']['type'] = $cmValue['type'];
					$data['Timetable']['exam_session'] = 'FN';
					$data['Timetable']['exam_date'] = $examDate;
		
					$data_exists=$this->Timetable->find('first', array(
							'conditions' => array(
									'Timetable.course_mapping_id'=>$cm_id,
									'Timetable.month_year_id'=>$exam_month_year_id,
							),
							'fields' => array('Timetable.id'),
							'recursive' => 0
					));
					if(isset($data_exists['Timetable']['id']) && $data_exists['Timetable']['id']>0) {
						$id = $data_exists['Timetable']['id'];
						$data['Timetable']['id'] = $id;
						$data['Timetable']['modified_by'] = $this->Auth->user('id');
						$data['Timetable']['modified'] = date("Y-m-d H:i:s");
					}
					else {
						$this->Timetable->create($data);
						$data['Timetable']['created_by'] = $this->Auth->user('id');
					}
					//pr($data);
					//$this->Timetable->save($data);
		
				}
			}
		}	
		//pr($timetableDatesAssigned);
	}
	
	public function examDateSelection($timetableDates, $timetableDatesAssigned, $daysDiff, $batch_duration) {
		//pr($timetableDates);
		if (empty($this->lastDateAssigned)) {
			if ($batch_duration % 2 == 0) {
				$examDate = $timetableDates[1];
			}
			else {
				$examDate = $timetableDates[2];
			}
			$this->lastDateAssigned[]=$examDate;
			return $examDate;
		}
		else {
			pr($this->lastDateAssigned); 
			$prvDate = $this->lastDateAssigned[count($this->lastDateAssigned)-1];
			$aKey = array_keys($timetableDates, $prvDate);
			//pr($aKey);
			$nextKey = $aKey[0] + $daysDiff;
			$nextDate = $timetableDates[$nextKey];
			$this->lastDateAssigned[]=$nextDate;
			//echo $nextDate;
			return $nextDate;
		}
	}
	
	public function dateRange($startDate, $endDate) {
		$array = array();
		$interval = new DateInterval('P1D');
		
		$realEnd = new DateTime($endDate);
		$realEnd->add($interval);
		
		$period = new DatePeriod(new DateTime($startDate), $interval, $realEnd);
		
		foreach($period as $date) {
			$array[] = $date->format('Y-m-d');
		}
		//pr($array);
		return $array;
	}
	
	public function loopProgramId($val) { //pr($val);
		$pgmToCheck = array();
		foreach ($val as $cmId => $innerArray) { //pr($innerArray);
			//list($semesterId, $examType, $programId, $batchId) = explode(",", $innerValue);
			$pgmToCheck[$innerArray['program_id']]=$innerArray['program_id'];
		}
		return $pgmToCheck;
	}
	
	/* public function checkIfExamDateIsAvailable ($programArray, $pgmToCheck, $examDate, $daysDiff) {
		//pr($pgmToCheck);
		if(empty($programArray)) return 0;
		foreach ($pgmToCheck as $programId) {
			foreach ($programArray as $pId => $previousExamDate) {
				if ($programId == $pId && $examDate == $previousExamDate) {
					return 1;
				} 
				else {
					return 0;
				}
			}
		}
	} */
	
	/* public function checkDaysDiff($programArray, $pgmToCheck, $examDate, $daysDiff) {
		$bool = 1;
		if (empty($programArray)) {
			return $bool;
		}
		foreach ($pgmToCheck as $programId) {
			foreach ($programArray as $pId => $previousExamDate) {
				if ($programId == $pId) {
					$date1 = new DateTime($previousExamDate);
					$date2 = new DateTime($examDate);
					$interval = $date1->diff($date2);
					$diff = $interval->d;
					if ($diff > $daysDiff) {
						return $bool;
					}
					else {
						$bool = 0;
						return $bool;
					}
				}
				else {
					return $bool;
				}
			}
		}
	} */
	
	public function common_code() {
		$ContinuousAssessmentExamsController = new ContinuousAssessmentExamsController;
		$monthyears = $ContinuousAssessmentExamsController->findMonthYear();
		
		$this->set(compact('monthyears'));
	}
	
	public function getTimetableData($exam_month_year_id) {
		$result = array(
				'conditions'=>array('Timetable.month_year_id'=>$exam_month_year_id),
				'fields' =>array('Timetable.id', 'Timetable.exam_type'),
				'contain'=>array(
						'CourseMapping'=>array('fields'=>array('CourseMapping.id',  'CourseMapping.program_id', 
											'CourseMapping.batch_id'),
								'Course'=>array('fields' =>array('Course.course_code', 'Course.course_name', 'Course.course_type_id')),
								'Batch'=>array('fields' =>array('Batch.batch_from', 'Batch.batch_to')),
						),
				),
				'recursive' => 1
		);
		$results = $this->Timetable->find("all", $result);
		return $results;
	}
	
	public function processTimetableData($results) {
		$commonCodeArray = array();
		//	echo count($results);
		
		foreach ($results as $key => $result) {
			$tmpArray = array();
			$tmpArray['timetable_id'] = $result['Timetable']['id'];
			$tmpArray['exam_type'] = $result['Timetable']['exam_type'];
			$tmpArray['cm_id'] = $result['CourseMapping']['id'];
			$tmpArray['batch_id'] = $result['CourseMapping']['batch_id'];
			$tmpArray['batch_duration'] = $result['CourseMapping']['Batch']['batch_to']-$result['CourseMapping']['Batch']['batch_from'];
			$tmpArray['program_id'] = $result['CourseMapping']['program_id'];
			$tmpArray['course_id'] = $result['CourseMapping']['course_id'];
			$tmpArray['course_code'] = $result['CourseMapping']['Course']['course_code'];
			$tmpArray['course_name'] = $result['CourseMapping']['Course']['course_name'];
			$tmpArray['course_type_id'] = $result['CourseMapping']['Course']['course_type_id'];
			array_push($commonCodeArray, $tmpArray);
		}
		return $commonCodeArray;
	}
	
	public function common_code_report($exam_month_year_id) {
		$results = $this->getTimetableData($exam_month_year_id);
//		pr($results);
		
		$commonCodeArray = $this->processTimetableData($results);
		//echo count($commonCodeArray);
		//pr($commonCodeArray);
		
		$groupedCommonCodeArray = $this->array_MultiOrderBy($commonCodeArray, 'course_code', SORT_ASC);
		//echo count($groupedCommonCodeArray);
		
		$groupedArray = $this->group_assoc($groupedCommonCodeArray, 'course_code');
		
		foreach ($groupedArray as $course_code => $tmpValue) {
			$batchGroupArray[$course_code] = $this->group_assoc($tmpValue, 'batch_duration');
		}
		//pr($batchGroupArray);		
		$finalArray = $this->noAppeared($batchGroupArray, $exam_month_year_id);
		//pr($finalArray);
		$this->layout = false;
		$this->set(compact('finalArray'));
	}
	
	public function noAppeared($groupedArray, $exam_month_year_id) {
		$finalArray = array();
		foreach ($groupedArray as $course_code => $value) {
			foreach ($value as $batch_duration => $val) {
				$total = 0;
				$totalAppeared = 0;
				$pass_count = 0;
				$start_range = '';
				$end_range = '';
				foreach ($val as $key => $array) {
					//pr($array);
					$tmpTotal = $this->ExamAttendance->find('count', array(
						'conditions'=>array('ExamAttendance.timetable_id'=>$array['timetable_id'])
					));
					$total = $total+$tmpTotal;
					
					$tmpTotalAppeared = $this->ExamAttendance->find('count', array(
							'conditions'=>array('ExamAttendance.timetable_id'=>$array['timetable_id'],
									'ExamAttendance.attendance_status'=>1
							)
					));
					$totalAppeared = $totalAppeared+$tmpTotalAppeared;
					
					$draResult = $this->Timetable->DummyRangeAllocation->find('all', array(
						'conditions'=>array('DummyRangeAllocation.timetable_id'=>$array['timetable_id']),
						'fields'=>array('DummyRangeAllocation.dummy_number_id'),
						'contain'=>array(
							'DummyNumber'=>array(
								'fields'=>array('DummyNumber.start_range', 'DummyNumber.end_range')
							)
						)
					));
					//pr($draResult);
					if(isset($draResult) && !empty($draResult)) {
						$start_range = $draResult[0]['DummyNumber']['start_range'];
						$end_range = $draResult[0]['DummyNumber']['end_range'];
					}
					
					$tmp_pass_count = $this->pass_count($array['cm_id'], $exam_month_year_id);
					
					$pass_count = $pass_count+$tmp_pass_count;
					//if ($array['course_code'] == 'SCH1101') {
					//echo "</br>".$array['exam_type']." ".$array['timetable_id']." ".$array['batch_id']." ".$array['program_id']." ".$array['cm_id']." ".$course_code." <b>".$tmpTotal."</b> ".$total." <b>".$tmpTotalAppeared."</b> ".$totalAppeared." <b>".$tmp_pass_count."</b> ".$pass_count;
					//}
				}
				$finalArray[$array['course_code']][$batch_duration] = array(
					'totalStrength'=>$total,
					'totalAppeared'=>$totalAppeared,
					'totalPass'=>$pass_count,
					'course_name'=>$array['course_name'],
					'start_range'=>$start_range,
					'end_range'=>$end_range,
				);
				//echo "</br>";
			}
		}
		//echo count($finalArray);
		return $finalArray;
	}
	
	public function pass_count($cmId, $monthYearId) {
		$pass_result = $this->StudentMark->query("
				SELECT count(*) as pass_count FROM student_marks StudentMark JOIN students Student ON StudentMark.student_id = Student.id WHERE StudentMark.id
				IN (SELECT max( id ) FROM student_marks sm1 WHERE StudentMark.student_id = sm1.student_id AND
				sm1.month_year_id = $monthYearId GROUP BY sm1.course_mapping_id ORDER BY sm1.id DESC)
				AND ((StudentMark.status = 'Pass' AND StudentMark.revaluation_status =0) OR
				(StudentMark.final_status = 'Pass' AND StudentMark.revaluation_status =1))
				AND StudentMark.month_year_id = $monthYearId
				AND StudentMark.course_mapping_id = ".$cmId."
				AND Student.discontinued_status=0
				ORDER BY StudentMark.student_id ASC
		");
		$tmp_pass_count = $pass_result[0][0]['pass_count'];
		return $tmp_pass_count;
	}
	
	public function group_assoc($array, $key) {
		$return = array();
		foreach($array as $v) {
			$return[$v[$key]][] = $v;
		}
		return $return;
	}
	
	public function programWise() {
		$academics = $this->Student->Academic->find('list');
		$batches = $this->Student->Batch->find('list', array('fields' => array('Batch.batch_period'), 'order'=>'Batch.id DESC'));
		
		$monthYears = $this->MonthYear->getAllMonthYears();
		
		$action = $this->action;
		$this->set(compact('batches', 'academics', 'programs', 'monthYears'));
	}
	
	public function program_wise_report($batchId, $academicId, $programId, $monthYearId) {
		$res = array(
				'conditions'=>array('CourseMapping.month_year_id'=>$monthYearId, 'CourseMapping.batch_id'=>$batchId,
						'CourseMapping.program_id'=>$programId,
						'CourseMapping.indicator'=>0
				),
				'fields' =>array('CourseMapping.id', 'CourseMapping.month_year_id'),
				'contain'=>array(
					'Timetable'=>array(
						'fields'=>array('Timetable.id'),
						'conditions'=>array('Timetable.month_year_id'=>$monthYearId),
							'ExamAttendance'=>array(
								'fields'=>array('ExamAttendance.id', 'ExamAttendance.attendance_status')
							),
					),
					'MonthYear'=>array(
							'fields' => array('MonthYear.year'),
							'Month' => array('fields' => array('Month.month_name'))
					),
					'EsePractical'=> array(
							'conditions'=>array('EsePractical.indicator'=>0,),
							'fields'=>array('EsePractical.id'),
							'Practical'=> array(
									'fields'=>array('Practical.id', 'Practical.marks'),
							)
					),
					'EseProject'=> array(
							'conditions'=>array('EseProject.indicator'=>0,),
							'fields'=>array('EseProject.id'),
							'ProjectViva'=> array(
									'fields'=>array('ProjectViva.id', 'ProjectViva.marks'),
							)
					),
					'CaePt'=> array(
							'conditions'=>array('CaePt.indicator'=>0,),
							'fields'=>array('CaePt.id'),
							'ProfessionalTraining'=> array(
									'fields'=>array('ProfessionalTraining.id', 'ProfessionalTraining.marks'),
									'conditions'=>array('ProfessionalTraining.month_year_id'=>$monthYearId)
							)
					),
				),
		);
		$results = $this->CourseMapping->find("all", $res);
		//pr($results); die;
		
		$finalArray = array();
		foreach ($results as $key => $result) {
			//pr($result);
			
			$course_details = $this->getCourseNameCrseCodeFromCMId($result['CourseMapping']['id']);
			//pr($course_details);
			$course_type_id = $course_details[0]['Course']['course_type_id'];
			$attArray = array();
			
			SWITCH ($course_type_id) {
				case 1:
					$totalStrength = count($result['Timetable'][0]['ExamAttendance']);
					$attArray = $result['Timetable'][0]['ExamAttendance'];
					//pr($attArray);
					$totAppeared = array_filter($attArray, array($this, 'present'));
					$totalAppeared = count($totAppeared);
					break;
				case 2:
				case 3:
				case 6:
					$absentee = 0;
					$totalStrength = count($result['EsePractical'][0]['Practical']);
					$attArray = $result['EsePractical'][0]['Practical'];
					foreach ($attArray as $key => $value) {
						if ($value['marks']=='A' || $value['marks']=='a' || $value['marks']=='AAA' || $value['marks']=='aaa') {
							$absentee++;
						}
					}
					$totalAppeared = $totalStrength - $absentee;
					break;
				case 4:
					$absentee = 0;
					$totalStrength = count($result['EseProject'][0]['ProjectViva']);
					$attArray = $result['EseProject'][0]['ProjectViva'];
					foreach ($attArray as $key => $value) {
						if ($value['marks']=='A' || $value['marks']=='a' || $value['marks']=='AAA' || $value['marks']=='aaa') {
							$absentee++;
						}
					}
					$totalAppeared = $totalStrength - $absentee;
					break;
				case 5:
					$absentee = 0;
					$totalStrength = count($result['CaePt']['ProfessionalTraining']);
					$attArray = $result['CaePt']['ProfessionalTraining'];
					foreach ($attArray as $key => $value) {
						if ($value['marks']=='A' || $value['marks']=='a' || $value['marks']=='AAA' || $value['marks']=='aaa') {
							$absentee++;
						}
					}
					$totalAppeared = $totalStrength - $absentee;
					break;
			}
			$tmp_pass_count = $this->pass_count($result['CourseMapping']['id'], $monthYearId);
			$passPercentage = round((100 * $tmp_pass_count) / $totalAppeared, 0);
			$finalArray[$result['CourseMapping']['id']] = array(
					'totalStrength'=>$totalStrength,
					'totalAppeared'=>$totalAppeared,
					'totalPass'=>$tmp_pass_count,
					'passPercent'=>$passPercentage,
					'course_code'=>$course_details[0]['Course']['course_code'],
					'course_name'=>$course_details[0]['Course']['course_name'],
					'month_year'=>$result['MonthYear']['Month']['month_name']."-".$result['MonthYear']['year'],
					'course_type_id'=>$course_type_id
			);
		}
		//pr($finalArray);
		$this->set(compact('finalArray'));
		$this->layout = false;
	}
	
	public function present($var) {
		return (is_array($var) && $var['attendance_status'] == 1);
	}
	
	public function course_search($examMonthYear=NULL) {
		$results = $this->getTimetableData($examMonthYear);
		//pr($results);
		
		$unOrderedArray = $this->processTimetableData($results);
		//echo count($commonCodeArray);
		//pr($unOrderedArray);
		
		$orderedArray = $this->array_MultiOrderBy($unOrderedArray, 'course_code', SORT_ASC);
		//echo count($orderedArray);
		//pr($orderedArray);
		
		$groupedArray = $this->group_assoc($orderedArray, 'course_code');
		//echo count($groupedArray);
		//pr($groupedArray);
		//pr($groupedArray);
		
		$courseArray = array();
		foreach ($groupedArray as $course_code => $array) {
			$courseArray[$array[0]['course_id']]=$course_code;
		}
		//echo count($courseArray)."*";
		/* $results = $this->StudentMark->query("
				SELECT sm.id, sm.course_mapping_id, sm.month_year_id, sm.student_id, s.registration_number, c.course_code,
				c.course_type_id, s.batch_id, s.program_id, cm.batch_id, cm.program_id, cm.month_year_id, cm.semester_id, c.id,
				b.batch_from, b.batch_to
				FROM student_marks sm
				JOIN students s ON sm.student_id=s.id
				JOIN course_mappings cm ON sm.course_mapping_id=cm.id
				JOIN courses c ON cm.course_id=c.id
				JOIN batches b ON b.id=cm.batch_id
				WHERE sm.id IN
				(SELECT max( id ) FROM student_marks sm1 WHERE sm.student_id =sm1.student_id
				AND sm1.month_year_id <= $examMonthYear
				GROUP BY course_mapping_id, sm1.student_id ORDER BY id DESC)
				AND ((sm.status='Fail' AND sm.revaluation_status=0) OR (sm.final_status='Fail' AND sm.revaluation_status=1))
				AND c.course_type_id in (2,3,4,6)
				AND sm.month_year_id <= $examMonthYear
				AND s.discontinued_status = 0
				ORDER BY sm.course_mapping_id  ASC");
		//pr($results);
		foreach ($results as $key => $array) {
			//echo $array['c']['course_code']."*".$array['c']['id']."@";
			$courseArray[$array['c']['id']]=$array['c']['course_code']." ".$array['c']['course_type_id'];
		} */
		asort($courseArray);
		//echo count($courseArray);
		$this->set('courseArray', $courseArray);
		$this->layout=false;
	}
	
}
