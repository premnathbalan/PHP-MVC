<?php
App::uses('AppController', 'Controller');
/**
 * PhdStudents Controller
 *
 * @property PhdStudent $PhdStudent
 * @property PaginatorComponent $Paginator
 */
class PhdStudentsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->PhdStudent->recursive = 0;
		$this->set('phdStudents', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->PhdStudent->exists($id)) {
			throw new NotFoundException(__('Invalid phd student'));
		}
		$options = array('conditions' => array('PhdStudent.' . $this->PhdStudent->primaryKey => $id));
		$this->set('phdStudent', $this->PhdStudent->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->PhdStudent->create();
			if ($this->PhdStudent->save($this->request->data)) {
				$this->Flash->success(__('The phd student has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The phd student could not be saved. Please, try again.'));
			}
		}
		$faculties = $this->PhdStudent->Faculty->find('list');
		$thesis = $this->PhdStudent->Thesi->find('list');
		$disciplines = $this->PhdStudent->Discipline->find('list');
		$supervisors = $this->PhdStudent->Supervisor->find('list');
		$months = $this->PhdStudent->Month->find('list');
		$monthYears = $this->PhdStudent->MonthYear->find('list');
		$this->set(compact('faculties', 'thesis', 'disciplines', 'supervisors', 'months', 'monthYears'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->PhdStudent->exists($id)) {
			throw new NotFoundException(__('Invalid phd student'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->PhdStudent->save($this->request->data)) {
				$this->Flash->success(__('The phd student has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The phd student could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('PhdStudent.' . $this->PhdStudent->primaryKey => $id));
			$this->request->data = $this->PhdStudent->find('first', $options);
		}
		$faculties = $this->PhdStudent->Faculty->find('list');
		$thesis = $this->PhdStudent->Thesi->find('list');
		$disciplines = $this->PhdStudent->Discipline->find('list');
		$supervisors = $this->PhdStudent->Supervisor->find('list');
		$months = $this->PhdStudent->Month->find('list');
		$monthYears = $this->PhdStudent->MonthYear->find('list');
		$this->set(compact('faculties', 'thesis', 'disciplines', 'supervisors', 'months', 'monthYears'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->PhdStudent->id = $id;
		if (!$this->PhdStudent->exists()) {
			throw new NotFoundException(__('Invalid phd student'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->PhdStudent->delete()) {
			$this->Flash->success(__('The phd student has been deleted.'));
		} else {
			$this->Flash->error(__('The phd student could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
