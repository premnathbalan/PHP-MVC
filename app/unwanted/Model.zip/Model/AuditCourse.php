<?php
App::uses('AppModel', 'Model');
/**
 * AuditCourse Model
 *
 */
class AuditCourse extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
