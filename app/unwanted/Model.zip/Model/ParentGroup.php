<?php
App::uses('AppModel', 'Model');

class ParentGroup extends Student {
	public $useTable = 'students';
}
